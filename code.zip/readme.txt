Install:
Copy the code folder into your feathers directory
Copy code.twig into your themes feathers directory
Add the contents of style.css to your themes stylesheets/screen.css file

You can now embed gists using [gist: 2729], replacing 2729 with your gists id.